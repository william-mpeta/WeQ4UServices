# Duplicate Documents / Standard / Sample_02

PROVISIONAL: no approved checklist is available. These are illustrative test fixtures, not a list of requirements.

Fictional customer: Thabo QA Dlamini
Synthetic ID: 8506247109083
Fictional vehicle: TEST 002 GP

All files are TEST DOCUMENTS - NOT FOR OFFICIAL USE.
